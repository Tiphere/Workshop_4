const { spawnSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const scenarios = [
    "leader_election", "heartbeats", "leader_failure", "log_replication",
    "follower_failure", "majority_lost", "network_partition", "log_recovery", "hardening"
];
const sections = [];
for (const scenario of scenarios) {
    const result = spawnSync(process.execPath, [path.join(__dirname, "scenarios", `${scenario}.js`)], { encoding: "utf8", cwd: __dirname });
    if (result.error || result.status !== 0) throw result.error || new Error(`${scenario} failed: ${result.stderr}`);
    const section = `=== ${scenario} ===\n${result.stdout}`;
    process.stdout.write(section);
    sections.push(section);
}
const directory = path.join(__dirname, "results");
fs.mkdirSync(directory, { recursive: true });
fs.writeFileSync(path.join(directory, "experiments.txt"), sections.join("\n"), "utf8");
console.log("\nResults saved to results/experiments.txt");
