class Network {
    constructor() {
        this.partitioned = false;
        this.groups = null;
    }

    send(message, from, to) {
        const blocked = this.partitioned && (
            !this.groups || !this.groups.has(from) || !this.groups.has(to) ||
            this.groups.get(from) !== this.groups.get(to)
        );
        const route = from && to ? `${from} -> ${to}: ` : "";
        console.log(`NETWORK ${blocked ? "DROPPED" : "DELIVERED"}: ${route}${message}`);
        return !blocked;
    }

    partition(groups = null) {
        this.partitioned = true;
        this.groups = groups ? new Map(groups.flatMap((ids, index) => ids.map(id => [id, index]))) : null;
        console.log("NETWORK PARTITION ACTIVE");
    }

    repair() {
        this.partitioned = false;
        this.groups = null;
        console.log("NETWORK PARTITION REPAIRED");
    }
}

module.exports = Network;
