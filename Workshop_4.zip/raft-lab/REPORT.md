# Workshop 4: Raft Consensus and Follower Lag Monitoring

COMSM0122 - Fundamentals of System Security  
Experimental Report  
Prepared: 21 October 2026

## Method

Nine scenario scripts cover Parts 1-10. Follower lag monitoring was selected as the Part 10 enhancement. Model corrections enable message delivery checks, voting, commitment and recovery to produce observable results. Output is recorded in `results/experiments.txt`; seven verification tests are recorded in `results/tests.txt`.

## Part 1: Establishing Authority

A, B and C initially had follower roles and term zero. B became a candidate in term one and received three votes, including its own. The required majority was two, so B became leader and sent initial heartbeats. Votes are granted according to term, vote history and log freshness. A node can vote for only one candidate in a term. Leadership is therefore established through majority support rather than by the timeout event alone. Elections are explicitly triggered in this model rather than scheduled by real timers.

## Part 2: Maintaining Leadership

B sent three periodic heartbeats after its initial leader announcement. A and C each received four empty AppendEntries messages in total. Their modelled election-elapsed counters returned to zero, while all log lengths remained zero. These messages maintained contact without introducing a new command. If communication stops, a deployment needs an election timeout to start a new attempt. The counters illustrate that behaviour; this implementation does not run an asynchronous timeout scheduler.

## Part 3: Leader Failure and Re-Election

B was elected in term one, then became unavailable. A started an election in term two and collected its own vote plus C's vote. Two votes met the three-node cluster's majority, so A became the replacement leader. The failed B was excluded from leader lookup and message participation. Higher terms identify newer authority, while vote restrictions prevent two elected leaders within one term under the model's assumptions. An unavailable node's old local role does not provide authority to commit new requests.

## Part 4: Replicating History

B accepted the client command `instances=10` and created log entry one in term one. AppendEntries delivered it to A and C, which stored independent copies and acknowledged receipt. Three acknowledgements exceeded quorum two, so B committed the entry and notified followers of the commit index. All nodes recorded one committed and applied command. Only delivered requests and replies count towards replication. This demonstrates in-memory replication and commitment, not durability after process or disk loss. A production deployment must persist the required state before acknowledging it.

## Part 5: Continuing Despite Failure

A was elected leader, then C became unavailable. A replicated `instances=10` to B. A's local copy and B's acknowledgement met quorum two, so both available nodes committed the entry. C retained an empty log. The three-node deployment can continue after one failure when the other two communicate and leadership remains usable. Another unavailable node would remove the majority. C's missing entry is recoverable history rather than evidence that every follower must respond before commitment.

## Part 6: When Progress Stops

The five-node cluster initially elected A. C, D and E then became unavailable, leaving two online nodes against quorum three. B's new election obtained two votes and failed. No current online leader could process the subsequent command, so no new entry was committed. The threshold was retained rather than weakened. Progress was unavailable, but the scenario produced no conflicting committed history. Online membership alone is insufficient when the required majority cannot participate.

## Part 7: Surviving a Network Partition

All five nodes first committed `instances=10`. The network then separated A/B/C from D/E. D obtained two votes and could not become leader. A continued with its majority and committed `instances=20`; D and E remained one entry behind. Cross-partition requests were dropped and were not counted as votes or acknowledgements. After repair, higher-term information caused A to step down. B was elected in term two with three votes, and D/E recovered the missing entry. The experiment demonstrates majority progress, minority isolation and subsequent term reconciliation within a synchronous model.

## Part 8: Repairing History

A replicated entry one to the cluster. C then became unavailable while A and B committed entries two and three. Before recovery, A's log contained three entries and C's contained one. After C returned, the model found their common prefix and sent the missing suffix through AppendEntries. C's log and commit index matched the leader, and an assertion verified equality. Recovery retained the existing prefix. A separate test also checks replacement of a conflicting uncommitted suffix while preserving the committed prefix.

## Part 9: Breaking Operational Assumptions

The hardening scenario rejected a 50 ms election timeout under an illustrative configured minimum of 100 ms. This is a local policy, not a universal Raft timing requirement. A supplied count of ten election events exceeded the churn threshold of five and generated a warning. Majority checks reported available at three of five nodes and unavailable at two of five. These examples examine configuration and event counts; they do not automatically detect a live election storm. The subsequent follower-lag demonstration measures state produced by actual model replication and recovery.

## Part 10: Follower Lag Monitoring

**Weakness.** An unavailable follower can accumulate missing committed history without a clear operational warning.

**Implementation.** `follower_lag.js` reports each follower's online state and the number of missing committed entries. It compares the leader's commit index with the follower's log length and warns when the difference exceeds the configured threshold. This provides visibility into replication backlog.

**Demonstration.** C was unavailable while A and B committed three entries. With threshold one, the monitor reported `FOLLOWER LAG WARNING` for C with three missing entries. After explicit recovery and catch-up, C's missing-entry count became zero and the warning cleared.

**Limitations.** The length-based metric assumes a matching log prefix and does not detect arbitrary corruption or misleading extra entries. It reads local model objects rather than performing remote health probes. Threshold selection is operational policy. Detection does not itself restore a node or initiate catch-up.

## Verification and Model Limits

Seven tests passed: dropped elections do not gain votes; dropped replication does not commit; a minority failure permits commitment; failed leaders are excluded; voting checks term and freshness; lag warnings clear after recovery; and uncommitted conflicts can be repaired without changing the committed prefix.

The implementation is a single-process, synchronous model. State is volatile, recovery retains in-memory objects, and timer events are invoked explicitly. Catch-up inspects local logs instead of implementing distributed next-index probing. Snapshots, client retry deduplication, membership changes, consistent-read protocols and Byzantine protection are outside this implementation.

## Source

COMSM0122, Workshop 4: Understanding and Stress-Testing Raft, workshop manual and supplied `raft-lab` source code.
