const LogEntry = require("./logEntry");

class Node {
    constructor(id) {
        this.id = id;
        this.role = "FOLLOWER";
        this.currentTerm = 0;
        this.votedFor = null;
        this.log = [];
        this.online = true;
        this.commitIndex = 0;
        this.lastApplied = 0;
        this.appliedCommands = [];
        this.electionElapsed = 0;
        this.heartbeatsReceived = 0;
    }

    becomeFollower(term) {
        if (term > this.currentTerm) this.votedFor = null;
        this.currentTerm = Math.max(this.currentTerm, term);
        this.role = "FOLLOWER";
    }

    becomeCandidate() {
        this.currentTerm++;
        this.role = "CANDIDATE";
        this.votedFor = this.id;
        this.electionElapsed = 0;
        console.log(`${this.id} -> CANDIDATE (TERM ${this.currentTerm})`);
    }

    becomeLeader() {
        this.role = "LEADER";
        console.log(`${this.id} -> LEADER (TERM ${this.currentTerm})`);
    }

    requestVote(term, candidateId, lastIndex, lastTerm) {
        if (!this.online || term < this.currentTerm) return false;
        if (term > this.currentTerm) this.becomeFollower(term);
        const last = this.log[this.log.length - 1];
        const localTerm = last ? last.term : 0;
        const localIndex = last ? last.index : 0;
        const upToDate = lastTerm > localTerm || (lastTerm === localTerm && lastIndex >= localIndex);
        if (upToDate && (this.votedFor === null || this.votedFor === candidateId)) {
            this.votedFor = candidateId;
            this.electionElapsed = 0;
            return true;
        }
        return false;
    }

    appendEntries(term, previousIndex, previousTerm, entries, leaderCommit) {
        if (!this.online || term < this.currentTerm) return false;
        this.becomeFollower(term);
        this.electionElapsed = 0;
        if (entries.length === 0) this.heartbeatsReceived++;
        const previous = this.log[previousIndex - 1];
        if (previousIndex > 0 && (!previous || previous.term !== previousTerm)) return false;

        for (const entry of entries) {
            const existing = this.log[entry.index - 1];
            if (existing && (existing.term !== entry.term || existing.command !== entry.command)) {
                if (entry.index <= this.commitIndex) return false;
                this.log.splice(entry.index - 1);
            }
            if (!this.log[entry.index - 1]) {
                this.log.push(new LogEntry(entry.index, entry.term, entry.command));
            }
        }
        this.commitIndex = Math.max(this.commitIndex, Math.min(leaderCommit, previousIndex + entries.length));
        this.applyCommitted();
        return true;
    }

    applyCommitted() {
        while (this.lastApplied < this.commitIndex) {
            this.appliedCommands.push(this.log[this.lastApplied].command);
            this.lastApplied++;
        }
    }

    fail() {
        this.online = false;
        console.log(`${this.id} OFFLINE`);
    }

    recover() {
        this.online = true;
        console.log(`${this.id} ONLINE`);
    }
}

module.exports = Node;
