class Cluster {
    constructor(nodes) {
        this.nodes = nodes;
    }

    majority() {
        return Math.floor(this.nodes.length / 2) + 1;
    }

    onlineNodes() {
        return this.nodes.filter(node => node.online);
    }

    hasMajority() {
        return this.onlineNodes().length >= this.majority();
    }

    leader() {
        return this.nodes.filter(node => node.online && node.role === "LEADER")
            .sort((a, b) => b.currentTerm - a.currentTerm)[0];
    }
}

module.exports = Cluster;
