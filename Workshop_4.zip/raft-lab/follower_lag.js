function reportFollowerLag(cluster, threshold = 1) {
    const leader = cluster.leader();
    if (!leader) {
        console.log("LAG MONITOR: no online leader");
        return [];
    }
    const rows = cluster.nodes.filter(node => node.id !== leader.id).map(node => {
        const missing = Math.max(0, leader.commitIndex - node.log.length);
        return { node: node.id, online: node.online, missingCommittedEntries: missing, warning: missing > threshold };
    });
    console.table(rows);
    for (const row of rows) {
        if (row.warning) console.log(`FOLLOWER LAG WARNING: ${row.node}, missing=${row.missingCommittedEntries}, threshold=${threshold}`);
    }
    return rows;
}

module.exports = reportFollowerLag;
