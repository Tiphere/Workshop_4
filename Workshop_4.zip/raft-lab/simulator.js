const LogEntry = require("./logEntry");

class Simulator {
    constructor(cluster, network) {
        this.cluster = cluster;
        this.network = network;
    }

    electLeader(node) {
        if (!node.online) return false;
        node.becomeCandidate();
        let votes = 1;
        const last = node.log[node.log.length - 1];
        for (const peer of this.cluster.nodes) {
            if (peer.id === node.id || !peer.online) continue;
            if (!this.network.send(`RequestVote(term=${node.currentTerm})`, node.id, peer.id)) continue;
            const granted = peer.requestVote(node.currentTerm, node.id, last ? last.index : 0, last ? last.term : 0);
            if (!this.network.send(`Vote ${granted ? "GRANTED" : "REJECTED"} (term=${peer.currentTerm})`, peer.id, node.id)) continue;
            if (peer.currentTerm > node.currentTerm) {
                node.becomeFollower(peer.currentTerm);
                return false;
            }
            if (granted) votes++;
        }
        console.log(`Votes = ${votes}/${this.cluster.nodes.length}; quorum = ${this.cluster.majority()}`);
        if (votes >= this.cluster.majority() && node.role === "CANDIDATE") {
            node.becomeLeader();
            this.heartbeat(node);
            return true;
        }
        console.log("ELECTION FAILED: no majority");
        return false;
    }

    sendAppend(leader, peer, previousIndex, entries) {
        if (!peer.online) return false;
        const previousTerm = previousIndex === 0 ? 0 : leader.log[previousIndex - 1].term;
        if (!this.network.send(`AppendEntries(term=${leader.currentTerm}, entries=${entries.length}, leaderCommit=${leader.commitIndex})`, leader.id, peer.id)) return false;
        const accepted = peer.appendEntries(leader.currentTerm, previousIndex, previousTerm, entries, leader.commitIndex);
        if (!this.network.send(`AppendEntries ${accepted ? "ACK" : "REJECTED"} (term=${peer.currentTerm})`, peer.id, leader.id)) return false;
        if (peer.currentTerm > leader.currentTerm) {
            leader.becomeFollower(peer.currentTerm);
            return false;
        }
        return accepted;
    }

    heartbeat(leader = this.cluster.leader()) {
        if (!leader || !leader.online || leader.role !== "LEADER") {
            console.log("NO ONLINE LEADER");
            return;
        }
        for (const peer of this.cluster.nodes) {
            if (leader.role !== "LEADER") break;
            if (peer.id !== leader.id) this.sendAppend(leader, peer, leader.log.length, []);
        }
    }

    synchronise(leader, follower) {
        let common = Math.min(leader.log.length, follower.log.length);
        while (common > 0) {
            const a = leader.log[common - 1];
            const b = follower.log[common - 1];
            if (a.term === b.term && a.command === b.command) break;
            common--;
        }
        return this.sendAppend(leader, follower, common, leader.log.slice(common));
    }

    replicate(command, leader = this.cluster.leader()) {
        if (!leader || !leader.online || leader.role !== "LEADER") {
            console.log("NO ONLINE LEADER");
            return { committed: false, acknowledgements: 0 };
        }
        const entry = new LogEntry(leader.log.length + 1, leader.currentTerm, command);
        leader.log.push(entry);
        console.log(`Leader ${leader.id} created entry: index=${entry.index}, term=${entry.term}, command=${command}`);
        let acknowledgements = 1;
        for (const peer of this.cluster.nodes) {
            if (leader.role !== "LEADER") break;
            if (peer.id !== leader.id && this.synchronise(leader, peer)) acknowledgements++;
        }
        const committed = leader.role === "LEADER" && entry.term === leader.currentTerm && acknowledgements >= this.cluster.majority();
        console.log(`Acknowledgements = ${acknowledgements}/${this.cluster.nodes.length}; quorum = ${this.cluster.majority()}`);
        if (committed) {
            leader.commitIndex = entry.index;
            leader.applyCommitted();
            console.log(`ENTRY COMMITTED: index=${entry.index}, command=${command}`);
            this.heartbeat(leader);
        } else {
            console.log("ENTRY NOT COMMITTED: majority unavailable or leadership changed");
        }
        return { committed, acknowledgements, entry };
    }

    catchUp(follower) {
        const leader = this.cluster.leader();
        if (!leader || !follower.online || follower.id === leader.id) return false;
        const success = this.synchronise(leader, follower);
        console.log(`${follower.id} LOG RECOVERY ${success ? "COMPLETE" : "FAILED"}`);
        return success;
    }
}

module.exports = Simulator;
