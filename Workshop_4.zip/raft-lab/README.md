# Workshop 4: Raft Consensus and Follower Lag Monitoring

COMSM0122 - Fundamentals of System Security

The project covers Parts 1-10. Follower lag monitoring is the selected final enhancement. The model demonstrates elections, heartbeats, replication, failures, partitions and recovery.

## Requirements

Node.js 18 or newer. No external packages are required.

## Run

Extract the ZIP and open its inner `raft-lab` folder.

- Windows: double-click `Run_Workshop.bat`. Node.js must be available in the command search path.
- macOS: double-click `Run_Workshop.command`.
- Terminal on either platform: run the following command inside `raft-lab`.

```text
node run_workshop.js
```

If the terminal is in the parent folder containing `raft-lab`, first enter:

```text
cd raft-lab
```

The runner executes nine scenarios and saves output to `results/experiments.txt`. Expected election or commitment failures in the failure scenarios are experimental outcomes.

Run verification tests with:

```text
node --test tests/workshop.test.js
```

## Individual Scenarios

| Part | Command |
| --- | --- |
| 1 | `node scenarios/leader_election.js` |
| 2 | `node scenarios/heartbeats.js` |
| 3 | `node scenarios/leader_failure.js` |
| 4 | `node scenarios/log_replication.js` |
| 5 | `node scenarios/follower_failure.js` |
| 6 | `node scenarios/majority_lost.js` |
| 7 | `node scenarios/network_partition.js` |
| 8 | `node scenarios/log_recovery.js` |
| 9-10 | `node scenarios/hardening.js` |

## Implementation

The model counts only delivered votes and replication acknowledgements. Elections check term, vote history and candidate log freshness. Commit indices and applied-command records distinguish local append, commitment and application. Recovery transfers a missing suffix and can repair an uncommitted conflict.

`follower_lag.js` reports missing committed entries and warns above a configured threshold. The hardening scenario demonstrates a warning at three missing entries and no warning after recovery.

This is a synchronous teaching model with in-memory state. Timers are represented by explicit events and counters. Log catch-up reads local objects, and the lag metric assumes matching prefixes. Durable storage, actual network transport and complete production Raft behaviour are not implemented. Detailed observations and limitations are documented in the report.

## Documentation

- `REPORT.md`: observations, explanations, enhancement and limitations.
- `results/experiments.txt`: recorded scenario output.
- `results/tests.txt`: recorded output from seven verification tests.
