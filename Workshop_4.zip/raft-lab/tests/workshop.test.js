const test = require("node:test");
const assert = require("node:assert/strict");
const createCluster = require("../fixture");
const Node = require("../node");
const LogEntry = require("../logEntry");
const reportFollowerLag = require("../follower_lag");

test("dropped election messages do not count as votes", () => {
    const { nodes, cluster, network, simulator } = createCluster();
    network.partition();
    assert.equal(simulator.electLeader(nodes[1]), false);
    assert.equal(cluster.leader(), undefined);
    assert.equal(nodes[0].votedFor, null);
    assert.equal(nodes[2].votedFor, null);
});

test("dropped replication does not create follower entries or commit", () => {
    const { nodes, network, simulator } = createCluster();
    simulator.electLeader(nodes[0]);
    network.partition();
    assert.equal(simulator.replicate("instances=10").committed, false);
    assert.equal(nodes[0].commitIndex, 0);
    assert.equal(nodes[1].log.length, 0);
    assert.equal(nodes[2].log.length, 0);
});

test("one unavailable follower still permits a majority commit", () => {
    const { nodes, simulator } = createCluster();
    simulator.electLeader(nodes[0]);
    nodes[2].fail();
    const result = simulator.replicate("instances=10");
    assert.equal(result.committed, true);
    assert.equal(result.acknowledgements, 2);
    assert.equal(nodes[0].commitIndex, 1);
    assert.equal(nodes[1].commitIndex, 1);
    assert.equal(nodes[2].log.length, 0);
});

test("an offline leader is excluded and replacement advances the term", () => {
    const { nodes, cluster, simulator } = createCluster();
    simulator.electLeader(nodes[1]);
    nodes[1].fail();
    assert.equal(cluster.leader(), undefined);
    assert.equal(simulator.replicate("instances=10").committed, false);
    assert.equal(simulator.electLeader(nodes[0]), true);
    assert.equal(cluster.leader().id, "A");
    assert.equal(cluster.leader().currentTerm, 2);
});

test("voting enforces one candidate per term and log freshness", () => {
    const node = new Node("A");
    node.currentTerm = 1;
    node.log.push(new LogEntry(1, 1, "instances=10"));
    assert.equal(node.requestVote(1, "B", 1, 1), true);
    assert.equal(node.requestVote(1, "C", 1, 1), false);
    assert.equal(node.requestVote(2, "C", 100, 0), false);
});

test("follower lag warning clears after committed entries are recovered", () => {
    const { nodes, cluster, simulator } = createCluster();
    simulator.electLeader(nodes[0]);
    nodes[2].fail();
    for (const count of [10, 20, 30]) simulator.replicate(`instances=${count}`);
    const before = reportFollowerLag(cluster, 1).find(row => row.node === "C");
    assert.equal(before.missingCommittedEntries, 3);
    assert.equal(before.warning, true);
    nodes[2].recover();
    assert.equal(simulator.catchUp(nodes[2]), true);
    const after = reportFollowerLag(cluster, 1).find(row => row.node === "C");
    assert.equal(after.missingCommittedEntries, 0);
    assert.equal(after.warning, false);
    assert.deepEqual(nodes[2].log, nodes[0].log);
    assert.deepEqual(nodes[2].appliedCommands, nodes[0].appliedCommands);
});

test("recovery repairs an uncommitted conflict while preserving the committed prefix", () => {
    const { nodes, simulator } = createCluster();
    const leader = nodes[0];
    leader.currentTerm = 2;
    leader.role = "LEADER";
    leader.log.push(new LogEntry(1, 1, "first"), new LogEntry(2, 2, "second"));
    leader.commitIndex = 2;
    leader.applyCommitted();
    const follower = nodes[2];
    follower.currentTerm = 1;
    follower.log.push(new LogEntry(1, 1, "first"), new LogEntry(2, 1, "conflict"));
    follower.commitIndex = 1;
    follower.applyCommitted();
    assert.equal(simulator.catchUp(follower), true);
    assert.deepEqual(follower.log, leader.log);
    assert.deepEqual(follower.appliedCommands, ["first", "second"]);
});
