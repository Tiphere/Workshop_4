const createCluster = require("../fixture");
const { nodes, simulator } = createCluster();
console.log("PART 4: LOG REPLICATION");
simulator.electLeader(nodes[1]);
simulator.replicate("instances=10");
console.table(nodes.map(n => ({ node: n.id, logEntries: n.log.length, committed: n.commitIndex, applied: n.lastApplied })));
