const createCluster = require("../fixture");
const { nodes, cluster, simulator } = createCluster();
console.log("PART 3: LEADER FAILURE");
simulator.electLeader(nodes[1]);
nodes[1].fail();
console.log("Election timeout event: A starts a new election");
simulator.electLeader(nodes[0]);
console.log(`Replacement leader: ${cluster.leader().id}; term=${cluster.leader().currentTerm}`);
console.table(nodes.map(n => ({ node: n.id, online: n.online, role: n.role, term: n.currentTerm })));
