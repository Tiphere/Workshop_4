const createCluster = require("../fixture");
const { nodes, simulator } = createCluster();
console.log("PART 2: HEARTBEATS");
simulator.electLeader(nodes[1]);
for (let i = 1; i <= 3; i++) {
    console.log(`\nPeriodic heartbeat ${i}`);
    nodes[0].electionElapsed = 50;
    nodes[2].electionElapsed = 50;
    simulator.heartbeat();
}
console.table(nodes.map(n => ({ node: n.id, role: n.role, logEntries: n.log.length, heartbeats: n.heartbeatsReceived, electionElapsed: n.electionElapsed })));
