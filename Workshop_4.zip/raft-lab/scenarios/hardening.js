const createCluster = require("../fixture");
const reportFollowerLag = require("../follower_lag");

console.log("PART 9: OPERATIONAL MONITORING");
function validateElectionTimeout(timeout) {
    if (!Number.isFinite(timeout) || timeout < 100) throw new Error("Election timeout below configured 100 ms policy");
}
function detectLeaderChurn(elections) {
    if (elections > 5) console.log(`LEADERSHIP CHURN WARNING: ${elections} supplied election events`);
}
function majorityAvailable(total, online) {
    return online >= Math.floor(total / 2) + 1;
}
try {
    validateElectionTimeout(50);
} catch (error) {
    console.log(`TIMEOUT CONFIGURATION REJECTED: ${error.message}`);
}
detectLeaderChurn(10);
console.log(`Majority available at 3/5: ${majorityAvailable(5, 3)}`);
console.log(`Majority available at 2/5: ${majorityAvailable(5, 2)}`);

console.log("\nPART 10: FOLLOWER LAG MONITORING");
const { nodes, cluster, simulator } = createCluster();
simulator.electLeader(nodes[0]);
nodes[2].fail();
for (const count of [10, 20, 30]) simulator.replicate(`instances=${count}`);
console.log("\nLag assessment before recovery");
reportFollowerLag(cluster, 1);
nodes[2].recover();
simulator.catchUp(nodes[2]);
console.log("\nLag assessment after recovery");
reportFollowerLag(cluster, 1);
