const createCluster = require("../fixture");
const { nodes, cluster, simulator } = createCluster(["A", "B", "C", "D", "E"]);
console.log("PART 6: MAJORITY LOSS");
simulator.electLeader(nodes[0]);
nodes.slice(2).forEach(n => n.fail());
console.log(`Online nodes: ${cluster.onlineNodes().length}; majority required: ${cluster.majority()}`);
const elected = simulator.electLeader(nodes[1]);
const result = simulator.replicate("instances=10");
console.log(`New leader elected: ${elected}; new entry committed: ${result.committed}`);
