const createCluster = require("../fixture");
const { nodes, simulator } = createCluster();
console.log("PART 5: FOLLOWER FAILURE");
simulator.electLeader(nodes[0]);
nodes[2].fail();
simulator.replicate("instances=10");
console.table(nodes.map(n => ({ node: n.id, online: n.online, logEntries: n.log.length, committed: n.commitIndex })));
