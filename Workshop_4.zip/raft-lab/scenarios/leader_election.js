const createCluster = require("../fixture");
const { nodes, simulator } = createCluster();
console.log("PART 1: LEADER ELECTION");
console.table(nodes.map(n => ({ node: n.id, role: n.role, term: n.currentTerm })));
simulator.electLeader(nodes[1]);
console.log(`Elected leader: ${nodes[1].role === "LEADER" ? nodes[1].id : "none"}; term=${nodes[1].currentTerm}`);
