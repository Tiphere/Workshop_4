const Node = require("./node");
const Cluster = require("./cluster");
const Network = require("./network");
const Simulator = require("./simulator");

function createCluster(ids = ["A", "B", "C"]) {
    const nodes = ids.map(id => new Node(id));
    const cluster = new Cluster(nodes);
    const network = new Network();
    return { nodes, cluster, network, simulator: new Simulator(cluster, network) };
}

module.exports = createCluster;
